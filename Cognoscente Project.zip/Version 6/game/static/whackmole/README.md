# Whack A Mole
## Created Using HTML, CSS & JavaScript

### See Tutorial on [YouTube](https://youtu.be/b20YueeXwZg)

### [Play Online](https://0shuvo0.github.io/whack-a-mole/)

![game preview](assets/preview.png)